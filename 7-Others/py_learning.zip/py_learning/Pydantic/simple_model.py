#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Project : py_learning
@File    : simple_model.py
@Author  : lsy
@Date    : 2026/8/16 17:48
@Desc    : Pydantic简单模型联系

注意：需要先安装pydantic，pip install pydantic
"""
from typing import Optional

from pydantic import BaseModel, Field, PositiveInt, field_validator


class Book(BaseModel):
    title:str = Field(...,min_length=1,description="标题")
    author:str = Field(...,min_length=1,description="作者")
    pages: PositiveInt  = Field(None,ge=1,le=10000,description="页数")
    genre: str = Field(default="unknown",description="类型")
    isbn: str = Field(pattern=r"^978-\d-\d{4}-\d{4}-\d$",description="ISBN")

    @field_validator("title")
    @classmethod
    def title_trip(cls,title:str)->str:
        if title.strip() == "":
            raise ValueError("书的标题是空白字符")
        return title.strip()

book1 = Book(title="平凡的世界",author="路遥",pages=890,genre="文学",isbn="978-3-6445-0033-9")
book1_json = book1.model_dump_json(indent=4)
print(book1_json)

book2 = Book(title="水浒传",author="施耐庵",isbn="978-3-6478-0065-8")
book2_json = book2.model_dump_json(indent=4)
print(book2_json)

# book3 = Book(title="",author="小明")
# book4 = Book(title="水浒传",author="施耐庵",pages=0)



