#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Project : py_learning
@File    : 1001_basics_practices.py
@Author  : lsy
@Date    : 2026/8/8 11:17
@Desc    : Python基础练习
"""
import shutil
from contextlib import contextmanager
from typing import Optional, Any, Callable


def celsius_to_fahrenheit(celsius:float) -> float:
    """ 将摄氏度转换为华氏温度
    Args:
        celsius: 摄氏度

    Returns:
        返回华氏温度
    """
    return celsius * 9 / 5 + 32

def fahrenheit_to_celsius(fahrenheit:float) -> float:
    """
    将华氏温度转换为摄氏度
    Args:
        fahrenheit: 华氏温度

    Returns:
        摄氏温度
    """
    return (fahrenheit - 32) * (5 / 9)

def is_prime(num:int) -> bool:
    """
    判断输入的整数是否为质数
    质数定义：一个大于1的自然数，若它的因数除了1和它本身，那么这个数就是质数。

    注意：如果 n = a × b，那么 a 和 b 不可能同时大于 sqrt(n)。因此如果 n 有因子，必然有一个 ≤ sqrt(n)。检查到 sqrt(n) 可以大幅减少循环次数。

    Args:
        num: 输入的整数

    Returns:
        bool: 是否为质数
    """
    if num < 2:
        return False
    for i in range(2,int(num**0.5)+1):
        if num % i == 0:
            return False
    else:
        return True

class Student:
    def __init__(self,name:str,scores:dict):
        self.name:str = name
        self.scores:dict = scores

    def average_score(self) -> float:
        """
        计算学生平均分

        Returns:
            float: 返回学生平均分
        """
        if not self.scores:
            return 0.0
        return sum(self.scores.values())/len(self.scores.keys())

    def best_subject(self) -> Optional[str]:
        """
        获取学生分数最高的科目名称

        Returns:
            str: 最好的科目名称
        """
        best_subject:Optional[str] = None
        best_score:float = float('-inf')
        if not self.scores:
            return best_subject
        for subject,score in self.scores.items():
            if score > best_score:
                best_score =score
                best_subject = subject
        return best_subject

def cache_result(func:Callable) -> Callable:
    """
    通过装饰器实现对于输入参数相同的从函数结果缓存中获取（缓存函数的计算结果）

    Args:
        func: 函数

    Returns:
        Callable: 可调用的函数
    """
    cache: dict[Any,Any] = {} # 用于缓存函数结果
    def wrapper(*args,**kwargs):
        """
        包装器函数
        Args:
            *args: 用于接收任意数量的位置参数
            **kwargs: 用于接收任意数量的关键字参数

        Returns:
            返回结果值
        """
        key = (args,frozenset(kwargs.items()))
        if key in cache:
            print(f"输入参数与之前输入相同，本次结果从缓存中获取...")
            return cache[key]
        else:
            func_result = func(*args,**kwargs)
            cache[key] = func_result
            return func_result
    return wrapper

@cache_result
def cal_func(x:int,y:int) -> int:
    print(f"结果计算中...")
    return x+y

@contextmanager
def file_backup(filepath:str):
    try:
        yield
    finally:
        bak_path = filepath + ".bak"
        print(f"bak_path is {bak_path}")

class FileBackup:
    def __init__(self,filepath:str):
        self.filepath:str = filepath
        self.bak_path:str = filepath + ".bak"

    def __enter__(self):
        shutil.copyfile(self.filepath,self.bak_path)
        return self

    def __exit__(self,exc_type,exc_value,exc_tb):
        if exc_type is not None:
            print(f"发生异常: {exc_value}")
        print(f"备份之后的目录: {self.bak_path}")

tool_registry = {}

def register_tool(tool_name:str):
    """
    工具注册表： 用字典推导式 + 装饰器实现一个工具注册表
    带参数的装饰器
    Args:
        tool_name: 工具名称

    Returns:
        返回装饰器函数
    """
    def decorator(func:Callable) -> Callable:
        """
        装饰器函数
        Args:
            func: 原始函数

        Returns:
            原始函数
        """
        tool_registry[tool_name] = func
        return func
    return decorator

@register_tool("search_web")  # ← 需要你实现 register_tool 装饰器
def search_web(query: str) -> list[str]:
    """搜索网络"""
    return [f"结果1: {query}",f"结果2: {query}"]


if __name__ == '__main__':
    cur_celsius: float= 36.5
    cur_fahrenheit: float = 80.9
    print(f"Celsius is {cur_celsius}, fahrenheit is {celsius_to_fahrenheit(cur_celsius)}")
    print(f"Fahrenheit is {cur_fahrenheit}, celsius is {fahrenheit_to_celsius(cur_fahrenheit)}")

    student_a = Student('小明',{'Chinese':91.5,'Math':99.0,'English':93.5})
    student_b = Student('小红', {'Chinese': 51.5, 'Math': 59.0, 'English': 63.5})
    print(f"{student_a.name}的各科平均分为{student_a.average_score()}")
    print(f"{student_a.name}的最好科目为{student_a.best_subject()}")
    print(f"{cal_func(12,15)}")
    print(f"{cal_func(12,16)}")
    print(f"{cal_func(12, 15)}")

    students = [student_a, student_b]
    result = [student.name for student in students if student.average_score()>=90]
    print(result)

    src_path = r"D:\ProgramData\test.txt"
    dist_path = src_path + ".bak"
    with file_backup(src_path):
        with open(src_path,'rb') as src, open(dist_path,'wb') as dist:
            shutil.copyfileobj(src,dist,length=64*1024)

    original_path = r"D:\ProgramData\fileback_test.txt"
    with FileBackup(original_path) as backup:
        print(f"正在处理文件：{original_path}")

    print(f"tool_registry is {tool_registry}")

    search_web_result1 = tool_registry["search_web"]("中国在哪个洲？")
    print(f"网络搜索工具搜索结果如下：{search_web_result1}")
    search_web_result2 = tool_registry["search_web"]("美国在哪个洲？")
    print(f"网络搜索工具搜索结果如下：{search_web_result2}")

