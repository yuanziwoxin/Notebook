
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Project : py_learning
@File    : hello_test.py
@Author  : lsy
@Date    : 2026/8/17 7:56
@Desc    : 这里写文件描述
"""
import time
# 1. 用类型注解定义参数 —— 自动校验 + 自动生成文档
from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.responses import HTMLResponse

# app = FastAPI()
#
# class HelloRequest(BaseModel):
#     name: str
#     times: int = 1
#
# @app.post("/hello")
# async def hello(req: HelloRequest):
#     # time.sleep(5000)  # ← 你定义了类型，FastAPI 自动做校验
#     return {"message": f"Hello {req.name}! " * req.times}
app = FastAPI()

@app.get("/", response_class=HTMLResponse)
async def root():
    return """
    <html>
        <body>
            <h1>🚀 FastAPI 已启动 </h1>
            <p> 访问 <a href="/docs">/docs</a> 查看 API 文档 </p>
        </body>
    </html>
    """
