## SSE

SSE（**Server-Sent Events**）：服务器推送事件，是一种基于HTTP的轻量级实时通信协议。允许服务器**单向**向客户端推送数据。

### 核心特点

| 特点          | 说明                                  |
| :------------ | :------------------------------------ |
| **单向通信**  | 服务器 → 客户端（只能推送，不能接收） |
| **基于 HTTP** | 使用标准 HTTP 协议，无需特殊协议      |
| **自动重连**  | 连接断开后浏览器自动重连              |
| **文本格式**  | 传输纯文本（通常是 JSON）             |
| **轻量级**    | 比 WebSocket 简单，资源占用少         |

### 工作原理

```javascript
// 客户端：建立连接
const eventSource = new EventSource('/api/stream');

// 服务器：持续推送
eventSource.onmessage = (event) => {
    console.log('收到:', event.data);
};
```

```text
客户端 ---- 建立 HTTP 连接 ----→ 服务器
        ←---- 推送 data: 你好 ----←
        ←---- 推送 data: 世界 ----←
        ←---- 推送 data: 完成 ----←
        (连接保持打开，随时推送)
```

### SSE vs WebSocket vs 轮询

| 维度           | SSE                   | WebSocket            | 轮询                  |
| :------------- | :-------------------- | :------------------- | :-------------------- |
| **通信方向**   | 单向（服务器→客户端） | 双向                 | 单向（客户端→服务器） |
| **协议**       | HTTP                  | WebSocket (独立协议) | HTTP                  |
| **自动重连**   | ✅ 原生支持            | ❌ 需手动实现         | ❌ 需手动实现          |
| **二进制数据** | ❌ 仅文本              | ✅ 支持               | ✅ 支持                |
| **复杂度**     | 低                    | 高                   | 中                    |
| **浏览器支持** | 所有现代浏览器        | 所有现代浏览器       | 所有浏览器            |
| **适用场景**   | 服务器推送通知        | 实时交互应用         | 低实时性需求          |

### 适用场景

#### 1.✅LLM 流式输出（最典型）

```javascript
// ChatGPT 的打字效果
const source = new EventSource('/chat/stream');
source.onmessage = (e) => {
    const chunk = JSON.parse(e.data);
    displayText += chunk.text;  // 逐字显示
};
```

**优势**：用户体验好，实时显示生成内容

#### 2. ✅ 实时通知/提醒

```javascript
// 邮件、订单状态更新
source.addEventListener('notification', (e) => {
    showToast(JSON.parse(e.data).message);
});
```

**优势**：无需刷新页面，自动接收新通知

#### 3. ✅ 进度条/任务状态

```javascript
// 文件上传、模型训练、数据导出
source.addEventListener('progress', (e) => {
    updateProgressBar(JSON.parse(e.data).percentage);
});
```

**优势**：实时显示任务进度，提升用户体验

#### 4. ✅ 实时数据推送

```javascript
// 股票价格、体育比分、新闻推送
source.onmessage = (e) => {
    updatePrice(JSON.parse(e.data));
};
```

**优势**：低延迟，无需频繁请求

#### 5. ✅ 日志流/监控

```javascript
// 服务器日志、应用监控
source.addEventListener('log', (e) => {
    appendLog(JSON.parse(e.data));
});
```

**优势**：实时查看系统运行状态

### 不适合使用的场景

#### ❌ 需要双向通信

```javascript
// 聊天室、在线游戏、协同编辑
// 应使用 WebSocket
const ws = new WebSocket('wss://chat.example.com');
ws.send({ message: '你好' });  // SSE 无法发送
```

#### ❌ 需要二进制数据

```javascript
// 音视频流、文件传输
// WebSocket 或 WebRTC 更合适
```

#### ❌ 极高频更新

```javascript
// 高频交易数据 (每秒上千次)
// WebSocket 性能更好
```

### 实际代码示例

#### 服务端（FastAPI）

```python
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
import asyncio
import json

app = FastAPI()

@app.get("/stream")
async def stream():
    async def generate():
        for i in range(10):
            yield f"data: {json.dumps({'progress': i*10})}\n\n"
            await asyncio.sleep(1)
        yield f"data: {json.dumps({'status': 'completed'})}\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no"
        }
    )
```

#### 客户端（JavaScript）

```javascript
const source = new EventSource('/stream');

// 监听所有消息
source.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log(data);
};

// 监听特定事件
source.addEventListener('progress', (event) => {
    const data = JSON.parse(event.data);
    document.getElementById('progress').textContent = data.progress + '%';
});

source.addEventListener('completed', () => {
    console.log('完成！');
    source.close();  // 关闭连接
});

// 错误处理（自动重连）
source.onerror = (error) => {
    console.log('连接断开，自动重连中...');
};
```

## 最佳实践

1. **使用事件类型区分不同数据**

```javascript
// 推送不同类型事件
event: token
data: {"text": "你"}

event: error
data: {"message": "超时"}

event: done
data: {"status": "完成"}
```

2. **设置超时和重连策略**

```javascript
const source = new EventSource('/stream', {
    withCredentials: true,
    // 默认重连间隔 3 秒
});

// 手动控制重连
let retryCount = 0;
source.onerror = () => {
    retryCount++;
    if (retryCount > 5) {
        source.close();
        alert('连接失败，请刷新重试');
    }
};
```

3. **使用 Last-Event-ID 支持断点续传**

```python
# 服务器读取客户端重连时的进度
last_event_id = request.headers.get("Last-Event-ID")
if last_event_id:
    # 从指定位置继续推送
    start_from = find_index(last_event_id)
```

## 总结

**SSE 是什么？**

- 基于 HTTP 的轻量级服务器推送技术
- 单向通信，自动重连，使用简单

**什么时候用 SSE？**

- ✅ 服务器需要推送数据到客户端
- ✅ 实时性要求中等（秒级延迟可接受）
- ✅ 只需单向通信（不需要客户端发消息）
- ✅ 希望实现简单、兼容性好

**典型应用：**

- LLM 流式输出（最常用）
- 实时通知/进度更新
- 监控/日志实时展示



## Prompt、Loop和Harness的关系

- Prompt是定义模型怎么工作的；
- Loop是驱动任务如何往前前进；
- Harness是保证系统实际允许发送什么事情；（定义行为的边界）

